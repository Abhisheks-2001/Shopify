---
'skeleton': patch
'@shopify/create-hydrogen': patch
---

Update skeleton and create-hydrogen cli to 3.75.4
