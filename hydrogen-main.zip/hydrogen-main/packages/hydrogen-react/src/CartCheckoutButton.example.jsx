import {CartCheckoutButton} from '@shopify/hydrogen-react';

export default function ProductCartCheckoutButton() {
  return <CartCheckoutButton />;
}
