# @shopify/create-hydrogen

This package generates a new Hydrogen project. Hydrogen is a set of tools, utilities, and best-in-class examples for building a commerce application with [Remix](https://wwww.remix.run).

[Check out the docs](https://shopify.dev/custom-storefronts/hydrogen)
