export const A = `#graphql
  query layout {
    shop {
      id
    }
  }
`;

export const B = `#graphql
  query layout {
    shop {
      name
      description
    }
  }
`;
