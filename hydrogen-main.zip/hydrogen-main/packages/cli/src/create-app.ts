#!/usr/bin/env node

import {runInit} from './commands/hydrogen/init.js';

runInit();
