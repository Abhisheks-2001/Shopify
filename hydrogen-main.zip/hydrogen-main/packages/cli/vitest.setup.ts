export const setup = () => {
  process.env.TZ = 'US/Eastern';
};
