@extends('layouts.app')
@section('content')
<body>

<h1>welecome to my website</h1>

<a href="{{route('logout')}}">LogOut</a>
</body>
@endsection