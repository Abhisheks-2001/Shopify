# frozen_string_literal: true

# Copyright The OpenTelemetry Authors
#
# SPDX-License-Identifier: Apache-2.0

module OpenTelemetry
  ## Current OpenTelemetry version
  VERSION = '1.0.2'
end
