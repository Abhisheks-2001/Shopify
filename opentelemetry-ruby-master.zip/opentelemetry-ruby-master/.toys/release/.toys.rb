# frozen_string_literal: true

toys_version!("~> 0.11", ">= 0.11.1")

desc "Release tools namespace"
