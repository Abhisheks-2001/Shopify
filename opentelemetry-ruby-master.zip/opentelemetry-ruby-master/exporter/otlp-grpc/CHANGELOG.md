# Release History: opentelemetry-exporter-otlp-grpc

### Unreleased

* ADDED: Boiler plate for a OTLP GRPC exporter implementation. It is not in a production ready state and will not be published until further improvements are made to it.
