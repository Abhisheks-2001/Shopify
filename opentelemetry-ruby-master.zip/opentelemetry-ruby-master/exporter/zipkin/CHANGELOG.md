# Release History: opentelemetry-exporter-zipkin

### v0.19.3 / 2021-12-01

* FIXED: Change net attribute names to match the semantic conventions spec for http 

### v0.19.2 / 2021-09-29

* (No significant changes)

### v0.19.1 / 2021-08-12

* DOCS: Update docs to rely more on environment variable configuration 

### v0.19.0 / 2021-06-23

* BREAKING CHANGE: Total order constraint on span.status= 

* FIXED: Total order constraint on span.status= 

### v0.18.0 / 2021-05-21

* BREAKING CHANGE: Replace Time.now with Process.clock_gettime 

* FIXED: Replace Time.now with Process.clock_gettime 

### v0.17.0 / 2021-04-22

* Initial release.
