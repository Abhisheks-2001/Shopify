# Release History: opentelemetry-instrumentation-active_record

### v0.3.0 / 2022-05-02

* ADDED: Make ActiveRecord 7 compatible 
* FIXED: RubyGems Fallback 

### v0.2.2 / 2021-12-01

* FIXED: Add max supported version for active record 

### v0.2.1 / 2021-09-29

* (No significant changes)

### v0.2.0 / 2021-09-29

* ADDED: Trace update_all and delete_all calls in ActiveRecord 
* FIXED: Remove Active Record instantiation patch 

### v0.1.1 / 2021-08-12

* (No significant changes)

### v0.1.0 / 2021-07-08

* Initial release, adds instrumentation patches to querying and persistence methods.
