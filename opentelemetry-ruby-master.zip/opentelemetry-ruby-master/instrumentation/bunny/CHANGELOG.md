# Release History: opentelemetry-instrumentation-bunny

### v0.18.5 / 2022-05-05

* (No significant changes)

### v0.18.4 / 2021-12-02

* (No significant changes)

### v0.18.3 / 2021-09-29

* (No significant changes)

### v0.18.2 / 2021-08-12

* DOCS: Update docs to rely more on environment variable configuration 

### v0.18.1 / 2021-06-23

* FIXED: Add missing require to bunny instrumentation 

### v0.18.0 / 2021-05-21

* Initial release.
