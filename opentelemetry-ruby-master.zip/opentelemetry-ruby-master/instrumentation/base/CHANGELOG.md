# Release History: opentelemetry-instrumentation-base

### v0.21.0 / 2022-05-26

* BREAKING CHANGE: This requires upgrading both the SDK and Instrumentation gem in tandem


### v0.20.0 / 2022-05-02

* ADDED: Validate Using Enums 
* FIXED: RubyGems Fallback 

### v0.19.0 / 2021-12-01

* ADDED: Add default options config helper + env var config option support 

### v0.18.3 / 2021-09-29

* (No significant changes)

### v0.18.2 / 2021-08-12

* (No significant changes)

### v0.18.1 / 2021-06-23

* (No significant changes)

### v0.18.0 / 2021-05-21

* ADDED: Updated API depedency for 1.0.0.rc1
* FIXED: Missing instrumentation classes during configuration

### v0.17.0 / 2021-04-22

* Initial release.
