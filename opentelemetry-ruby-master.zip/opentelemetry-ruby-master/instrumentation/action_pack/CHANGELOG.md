# Release History: opentelemetry-instrumentation-action_pack

### v0.1.4 / 2022-05-02

* FIXED: Use rails request's filtered path as http.target attribute 
* FIXED: RubyGems Fallback 

### v0.1.3 / 2021-12-01

* FIXED: Instrumentation of Rails 7 

### v0.1.2 / 2021-10-06

* FIXED: Prevent high cardinality rack span name as a default 

### v0.1.1 / 2021-09-29

* (No significant changes)

### v0.1.0 / 2021-08-12

* Initial release.
