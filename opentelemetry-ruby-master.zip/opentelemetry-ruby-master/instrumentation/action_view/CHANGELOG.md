# Release History: opentelemetry-instrumentation-action_view

### v0.2.1 / 2022-05-02

* FIXED: RubyGems Fallback 

### v0.2.0 / 2021-12-01

* ADDED: Move activesupport notification subsciber out of action_view gem 
* FIXED: Instrumentation of Rails 7 

### v0.1.3 / 2021-10-06

* FIXED: Do not replace fanout 

### v0.1.2 / 2021-09-29

* (No significant changes)

### v0.1.1 / 2021-09-09

* FIXED: Keep Active Support subscriptions intact when patching 

### v0.1.0 / 2021-08-12

* Initial release.
