# Release History: opentelemetry-instrumentation-active_support

### v0.1.2 / 2022-05-05

* (No significant changes)

### v0.1.1 / 2021-12-02

* (No significant changes)

### v0.1.0 / 2021-11-09

* Initial release.
